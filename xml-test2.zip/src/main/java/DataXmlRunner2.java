

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DataXmlRunner2 {
 
	public static String getTagValue(String tag, Element eElement) { //태그값을 받아옴
		String result = ""; // 나중에 리턴값을 받음

		NodeList nList = eElement.getElementsByTagName(tag).item(0).getChildNodes();
		result = nList.item(0).getTextContent();

		return result;
	}

	public static void main(String[] args) {
		String apiKey = "";
		try {
			String url = "http://openapi.q-net.or.kr/api/service/rest/InquiryTestInformationNTQSVC/getJMList?jmcd="+value+"&serviceKey=dn5V7VHzMAAH9UmfOInjhNIBWgJak1bNISgkquqQu7anHP%2BpKIBznJZtPV6%2FFGYD88Htbt8kVBuW3MGh7rVvHA%3D%3D&jmCd=0080";
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(url);
			NodeList nList = doc.getElementsByTagName("item");
			// 제일첫번째태그?
			doc.getDocumentElement().normalize();
			for (int i = 0; i < nList.getLength(); i++) {
				Node nNode = nList.item(i);
				Element eElement = (Element) nNode;
				
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					
					System.out.println("====================");
					System.out.println("종목코드: " + getTagValue("jmcd", eElement));
					System.out.println("종목명: " + getTagValue("jmfldnm", eElement));
					System.out.println("대직무분야코드: " + getTagValue("obligfldcd", eElement));
					System.out.println("대직무분야명: " + getTagValue("obligfldnm", eElement));
					System.out.println("중직무분야코드: " + getTagValue("mdobligfldcd", eElement));
					System.out.println("중직무분야명: " + getTagValue("mdobligfldnm", eElement));
					System.out.println("계열코드: " + getTagValue("seriescd", eElement));
					System.out.println("계열명(~사): " + getTagValue("seriesnm", eElement));
					System.out.println("자격구분: (T:기술사 S: 전문자격) : " + getTagValue("qualgbcd", eElement));
					System.out.println("자격명: " + getTagValue("qualgbnm", eElement));
					System.out.println("====================");
					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}